import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = process.env.PORT || 9091;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Serve static HTML pages from public directory
app.use(express.static(path.join(__dirname, '../../public')));

app.get('/api/v1/health', (req, res) => {
  console.log('Health check success');
  res.status(200).json({ status: 'ok' });
});

// Serve mamamoon-menu.html at root path
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../../public/mamamoon-menu.html'));
});

app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}/`);
  console.log(`MamaMoon menu: http://localhost:${port}/mamamoon-menu.html`);
});
